package rewards.internal.monitor;

public interface Monitor {

	Monitor start();

	Monitor stop();
}
